<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_records() {
        return $this->db->get('customer')->result_array();
    }

    public function get_record($id) {
        return $this->db->get_where('customer', array('Id' => $id))->row_array();
    }

      public function saverecords($data) {
        $this->db->insert('customer', $data);
        return $this->db->affected_rows() > 0;
    }



    public function get_record_by_id($id) {
        $this->db->where('Id', $id);
        $query = $this->db->get('customer'); 
        return $query->row_array(); 
    }

    public function update_record($id, $data) {
  
        $this->db->where('Id', $id);
        $this->db->update('customer', $data); 
    }



    // public function update_record($id, $data) {
    //     $this->db->where('Id', $id);
    //     $this->db->update('customer', $data);
    //     return $this->db->affected_rows() > 0;
    // }

    public function delete_record($id) {
        $this->db->where('Id',$id);
        $this->db->delete('customer');
        return $this->db->affected_rows() > 0;
    }
       
}
?>
