<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url'); 
        $this->load->model('User_model');
    }

    public function index() {
        $data['records'] = $this->User_model->get_approved_records();
        $this->load->view('user_dashboard', $data);
    }

    // public function index() {
    //     $data['records'] = $this->User_model->get_records2();
    //     $this->load->view('user_dashboard', $data);
    // }

    public function add_record() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[permission.Email]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('role', 'Role', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('user_dashboard');
        } else {
            $data = array(
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'role' => $this->input->post('role'),
                'Approval' => 0 
            );
            $this->User_model->insert_record($data);
            redirect('User_dashboard');
        }
    }


    // public function savedata() {
    //     if($this->input->post()) {
    //         $data['username'] = $this->input->post('Username');
    //         $data['email'] = $this->input->post('Email');
    //         $data['password'] = $this->input->post('Password');
    //         $data['role'] = $this->input->post('role');

    //         $response = $this->User_model->saverecords($data);

    //         if($response) { 
    //             echo '<script>alert("Inserted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
    //         } else {
    //             echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
    //         }
    //     }
    // }




    public function edit1($id) {
        $record = $this->User_model->get_record($id);
        if ($record && $record['Approval'] == 0) {
            $data['record'] = $record;
            $this->load->view('edit1', $data);
        } else {
            echo '<script>alert("Sorry,didnot edit this Data,because this Data is Approved..."); window.location.href="'.base_url('User_dashboard').'";</script>';
        }
    }
    

    public function update() {
        if($this->input->post()) {
            $id =   $this->input->post('id'); 
            $data['username'] = $this->input->post('username'); 
            $data['email'] = $this->input->post('email'); 
            $data['password'] = $this->input->post('password'); 
            $data['role'] = $this->input->post('role');
    
            $response = $this->User_model->update_record($id, $data);
    
            if($response) { 
                echo '<script>alert("Updated!"); window.location.href="'.base_url('User_dashboard').'";</script>';
            } else {
                echo '<script>alert("Not Updated!"); window.location.href="'.base_url('User_dashboard').'";</script>';
            }
        }
    } 
    

    public function delete($id) {
        $response = $this->User_model->delete_record($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('User_dashboard').'";</script>';
        } else {
            echo '<script>alert("Not Deleted!"); window.location.href="'.base_url('User_dashboard').'";</script>';
        }
    }
}
