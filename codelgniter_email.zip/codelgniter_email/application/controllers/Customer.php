<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('customer_model');
        $this->load->library('email');
        $this->load->helper(array('form', 'url'));
        $this->load->library('upload');        // $this->load->model('customer_model');
    }

    public function index() {
        $data['records'] = $this->customer_model->get_records();
        $this->load->view('customer_view', $data);
    }
    
    public function savedata() {
        if($this->input->post()) {
            $data['customer_name'] = $this->input->post('Customer_name');
            $data['customer_age'] = $this->input->post('Customer_age');
            $data['customer_contact'] = $this->input->post('Customer_contact');
            $data['customer_email'] = $this->input->post('Customer_email');
            // $data['customer_name'] = $this->input->post('customer_name');

            $response = $this->customer_model->saverecords($data);

            if($response) { 
                echo '<script>alert("Inserted!"); window.location.href="'.base_url('Customer').'";</script>';
            } else {
                echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Customer').'";</script>';
            }
        }
    }

    
    public function edit($id) {
        $record = $this->customer_model->get_record_by_id($id);         
        $this->load->view('edit', array('record' => $record));
    }

    public function update($id) {
   
        $data = array(
            'Customer_name' => $this->input->post('customer_name'),
            'Customer_age' => $this->input->post('customer_age'),
            'Customer_contact' => $this->input->post('customer_contact'),
            'Customer_email' => $this->input->post('customer_email')
        );

        $this->customer_model->update_record($id, $data);

        redirect('customer'); 
        }

    public function delete($id) {
        $response = $this->customer_model->delete_record($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Customer').'";</script>';
        } else {
            echo '<script>alert("Not Deleted!"); window.location.href="'.base_url('Customer').'";</script>';
        }
    }





    public function upload_file() {
        $config['upload_path'] = './Uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 1024; 

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('userfile')) {
            $error = $this->upload->display_errors();
            echo $error;
        } else {
            // $uploads_folder = "Uploads";
            // $file_path = FCPATH . $uploads_folder . "/" ;
            // print_r(  $file_path);
            // exit;
            // File uploaded successfully
            // Redirect or show success message
            echo '<script>alert("File uploaded successfully."); window.location.href="'.base_url('Customer').'";</script>';
            // echo "File uploaded successfully.";
        }
    }
 


// public function send_email() {
//     // Check if the form is submitted
//     if ($this->input->post('send_email')) {
//         // Get the recipient email from the form
//         $to_email = $this->input->post('customer_email');

//         // Set sender email
//         $from_email = 'omsakthivel143@gmail.com';

//         // Set email subject and message
//         $subject = 'Subject of the Email';
//         $message = 'Content of the email goes here.';

//         // Load email library
//         $this->load->library('email');

//         // Set email configuration
//         $config['protocol'] = 'smtp';
//         $config['smtp_host'] = 'smtp.gmail.com';
//         $config['smtp_user'] = 'omsakthivel143@gmail.com';
//         $config['smtp_pass'] = 'iqqi edus pyto uslv'; // Make sure to use your Gmail App Password here
//         $config['smtp_port'] = 465; // Corrected the port to 465 for SSL
//         $config['smtp_crypto'] = 'ssl'; // Use SSL encryption
//         $config['mailtype'] = 'html';
//         $config['charset'] = 'utf-8';
//         $config['wordwrap'] = TRUE;
//         $config['newline'] = "\r\n";
//         $this->email->initialize($config);

//         // Set email headers
//         $this->email->from($from_email, 'sakthi');
//         $this->email->to($to_email);
//         $this->email->subject($subject);
//         $this->email->message($message);

//         // Handle file attachment
//         if (!empty($_FILES['attachment']['name'])) {
//             $this->email->attach($_FILES['attachment']['tmp_name'], $_FILES['attachment']['name']);
//         }

//         // Send email
//         if ($this->email->send()) {
//              echo '<script>alert("Email Sended Succesfully...."); window.location.href="'.base_url('Customer').'";</script>';
//         } else {
//             // Display error message if email sending fails
//             echo "Email sending failed. Error: " . $this->email->print_debugger();
//         }
//     }

    
// }
// Controller (Customer.php)

public function get_upload_files() {
    $uploads_folder = './Uploads/';
    $files = array_diff(scandir($uploads_folder), array('..', '.')); 
    $files = array_values($files); 
    echo json_encode($files);
}


public function send_email() {
    if ($this->input->post('send_email')) {
        $to_email = $this->input->post('customer_email');

        $selected_file = $this->input->post('selected_file');

        $from_email = 'omsakthivel143@gmail.com';

        $subject = 'Subject of the Email';
        $message = 'Content of the email goes here.';

        $this->load->library('email');

        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'smtp.gmail.com';
        $config['smtp_user'] = 'omsakthivel143@gmail.com';
        $config['smtp_pass'] = 'iqqi edus pyto uslv'; 
        $config['smtp_port'] = 465; 
        $config['smtp_crypto'] = 'ssl'; 
        $config['mailtype'] = 'html';
        $config['charset'] = 'utf-8';
        $config['wordwrap'] = TRUE;
        $config['newline'] = "\r\n";
        $this->email->initialize($config); 

        $this->email->from($from_email, 'sakthi');
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);

        if (!empty($selected_file)) {
            $uploads_folder = "Uploads";
            $file_path = FCPATH . $uploads_folder . "/" . $selected_file;
            // print_r($file_path);
            // exit;
            if (file_exists($file_path)) {
                $this->email->attach($file_path);
            } else {
                echo "Selected file does not exist.";
                return;
            } 
        }

        if ($this->email->send()) {
  echo '<script>alert("Email Sended Succesfully...."); window.location.href="'.base_url('Customer').'";</script>';

        } else {
            echo "Email sending failed. Error: " . $this->email->print_debugger();
        }
    }
}




}
    
?>