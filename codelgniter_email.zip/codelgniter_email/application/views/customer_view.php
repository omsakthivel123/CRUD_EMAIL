<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Application</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1 class="text-center">Records</h1><br>
        <table class="table table-bordered text-lite">
            <thead>
                <tr>
                    <th class="text-center">Id</th>
                    <th class="text-center">Customer Name</th>
                    <th class="text-center">Age</th>
                    <th class="text-center">Contact</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>  
            <tbody>
                <?php if(isset($records) && !empty($records)): ?>
                    <?php foreach($records as $record): ?> 
                        <tr>
                            <td><?= $record['Id'] ?></td>
                            <td><?= $record['Customer_name'] ?></td>
                            <td><?= $record['Customer_age'] ?></td>
                            <td><?= $record['Customer_contact'] ?></td>
                            <td class="email-col"><?= $record['Customer_email'] ?></td>
                            <td>
                                <button class="btn btn-success send-email" data-toggle="modal" data-target="#fileModal">Send Email</button>
                                <a href="<?= base_url('Customer/edit/'.$record['Id']) ?>" class="btn btn-success">Edit</a>
                                <a href="<?= base_url('Customer/delete/'.$record['Id']) ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?> 
                <?php else: ?>
                    <tr><td colspan="6">No records found</td></tr>
                <?php endif; ?>
            </tbody> 
        </table> 
    </div> 

    <div class="container mt-5">
        <h2>Upload File</h2>
        <form method="post" action="<?= base_url('Customer/upload_file'); ?>" enctype="multipart/form-data">
            <div class="form-group">
                <label for="userfile">Select File:</label>
                <input type="file" class="form-control-file" id="userfile" name="userfile">
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>
     
    <div class="container mt-5">
        <h2>Customer Information</h2>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#customerModal">Add Customer</button>

        <div class="modal fade" id="customerModal" tabindex="-1" role="dialog" aria-labelledby="customerModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="customerModalLabel">Add Customer</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="customerForm" method="post" action="<?= base_url('Customer/savedata'); ?>">
                            <div class="form-group">
                                <label for="Customer_name">Name:</label>
                                <input type="text" class="form-control" id="Customer_name" name="Customer_name">
                            </div>
                            <div class="form-group">
                                <label for="Customer_age">Age:</label>
                                <input type="text" class="form-control" id="Customer_age" name="Customer_age">
                            </div>
                            <div class="form-group">
                                <label for="Customer_contact">Contact:</label>
                                <input type="text" class="form-control" id="Customer_contact" name="Customer_contact">
                            </div>
                            <div class="form-group">
                                <label for="Customer_email">Email:</label>
                                <input type="text" class="form-control" id="Customer_email" name="Customer_email">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" form="customerForm" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <form id="email-form" method="post" action="<?= base_url('Customer/send_email') ?>" enctype="multipart/form-data" style="display: none;">
        <input type="hidden" name="customer_email" id="customer_email">
        <input type="hidden" name="send_email" value="1">
        <input type="hidden" name="selected_file" id="selected_file">
    </form>

    <div class="modal fade" id="fileModal" tabindex="-1" role="dialog" aria-labelledby="fileModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fileModalLabel">Select File</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <select id="fileSelect" class="form-control">
                        <option value="">Select File</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="attachFileBtn">Attach File</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.send-email').forEach(function(button) {
            button.addEventListener('click', function() {
                var customerEmail = this.parentNode.parentNode.querySelector('.email-col').textContent.trim();
                document.getElementById('customer_email').value = customerEmail;

                fetch('<?= base_url('Customer/get_upload_files') ?>')
                    .then(response => response.json())
                    .then(data => {
                        var fileSelect = document.getElementById('fileSelect');
                        fileSelect.innerHTML = '';
                        data.forEach(function(file) {
                            var option = document.createElement('option');
                            option.value = file;
                            option.text = file;
                            fileSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching files:', error));
            });
        });

        document.getElementById('attachFileBtn').addEventListener('click', function() {
            var selectedFile = document.getElementById('fileSelect').value;
            if (selectedFile) {
                document.getElementById('selected_file').value = selectedFile;
                document.getElementById('email-form').submit();
            } else {
                alert('Please select a file.');
            }
        });
    </script>
</body>
</html>
