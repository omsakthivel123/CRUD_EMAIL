<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

   public function register_user() {
        $data = array(
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'password' =>$this->input->post('password'),
            'role' => $this->input->post('role'),
            // 'Approval' => ($this->input->post('role') == 1) ? 0 : 1 
            

        );

        return $this->db->insert('permission', $data);
    }


    
    public function get($username, $password) {
        $query = $this->db->get_where('permission', array('Username' => $username), 1);
        $user = $query->row();
    
        if ($user && $user->Password == $password) {
            return $user; 
        } else {
            return false; 
        }
    }

    
    
            //   ------------------------ user-------------
            
            public function get_approved_records() {
                $query = $this->db->get_where('permission');
                return $query->result_array();
            }
            // public function get_records2() {
            //     $query = $this->db->get('permission');
            //     return $query->result_array();
            // }
        
            public function insert_record($data) {
                return $this->db->insert('permission', $data);
            }

        public function get_record($id) {
            return $this->db->get_where('permission', array('Id' => $id))->row_array();
        }
    
        public function update_record($id, $data) {
            $this->db->where('Id', $id);
            return $this->db->update('permission', $data);
        }
    
        public function delete_record($id) {
            $this->db->where('Id',$id);
            $this->db->delete('permission');
            return $this->db->affected_rows() > 0;
        }


        // --------------------admin------------

       
    public function get_records() {
        
            $query = $this->db->get_where('permission', array('Approval' => 0));
            return $query->result_array();
    }

    public function update_approval($id, $approval) {
        $this->db->where('Id', $id);
        $this->db->update('permission', array('Approval' => $approval));
    }
}
    ?>
    

    

