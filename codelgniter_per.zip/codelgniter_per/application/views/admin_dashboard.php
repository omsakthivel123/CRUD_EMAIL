<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>

    <div class="container mt-5 bg-lite">
        <h2 class="mt-5 text-center">ADMINISTRATOR</h2><br>

        <div style="display:flex; justify-content:right;">
            <a href="<?php echo base_url('Auth/index')?>" class="btn btn-info text-right" role="button">Login</a>
        </div><br>
        
        <table class="table table-bordered text-lite" id="records-table">
            <thead>
                <tr> 
                    <th class="text-center">ID</th>
                    <th class="text-center">Username</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Password</th>
                    <th class="text-center">Role</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody  class="text-center">
                <?php foreach($records as $record): ?>
                    <tr id="row-<?php echo $record['Id']; ?>">
                        <td><?= $record['Id'] ?></td>
                        <td><?= $record['Username'] ?></td>
                        <td><?= $record['Email'] ?></td>
                        <td><?= $record['Password'] ?></td>
                        <td><?= $record['role'] ?></td>
                        <td>
                            <a href="<?= base_url('Admin_dashboard/change_approval/'.$record['Id'].'/1') ?>" class="btn btn-success yes-btn">Approve</a>
                            <a href="<?= base_url('Admin_dashboard/change_approval/'.$record['Id'].'/0') ?>" class="btn btn-danger no-btn">Pending..</a>
                        </td>
                    </tr>
                <?php endforeach; ?> 
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function(){
            $('.yes-btn').click(function(e){
                e.preventDefault(); 
                var rowId = $(this).closest('tr').attr('id'); 
                var url = $(this).attr('href'); 

                $.ajax({
                    url: url,
                    type: 'GET',
                    success: function(response) {
                        
                        $('#' + rowId).remove();
                    },
                    
                });
            });
        });
    </script>

</body>
</html>
