<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->helper('url');
    }
    
     public function index() {
        $data['records'] = $this->User_model->get_records();
        $this->load->view('admin_dashboard', $data);
    }

    public function change_approval($id, $approval) {
        $this->User_model->update_approval($id, $approval);
        redirect('admin_dashboard');
    } 

  

}
?>
