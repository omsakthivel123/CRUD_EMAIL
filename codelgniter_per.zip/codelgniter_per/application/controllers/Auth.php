<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session'); 
        $this->load->model('User_model');
    }
    

    public function index() {
       
       
        $this->load->view('login'); 
    }
 
    public function reg(){
       $this->load->view('register'); 
    }

    public function register() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[permission.Email]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('role', 'role', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            echo '<script>alert ("Email address already exists. Please choose a different email")</script> ';
            $this->load->view('login');
        } else {
            $registration_result = $this->User_model->register_user();
    
            if ($registration_result) {
                redirect('auth');
            } else {
                $data['error_msg'] = 'Email address already exists. Please choose a different email.';
                $this->load->view('login', $data); 
            }
        }
    }
    



    public function login() {
        
        $username = $this->input->post('username');
        $password = $this->input->post('password');
    
        $this->load->model('User_model');
        $user = $this->User_model->get($username, $password);
    
        if ($user) {
            if ($user->role == 'admin') {
                redirect('Admin_dashboard');
            } else {
                redirect('User_dashboard');
            }
        } else {
            echo "Login failed. Please check your username and password.";
        }
    }

    
    
    }?>