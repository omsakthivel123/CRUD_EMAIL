<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php echo validation_errors('<div class="error">', '</div>'); ?>
    <?php if(isset($error)) { echo '<div class="error">' . $error . '</div>'; } ?>
    <?php echo form_open('Login/authenticate'); ?>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo set_value('username'); ?>" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login">
    <?php echo form_close(); ?>
</body>
</html>
