
<!-- Insert Data Form and Records Table -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp form</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5  ">
        <h2 class="text-warning text-center text-info">Sign up</h2>
        <form action="<?= base_url('Sign_up/savedata') ?>" method="post">
            <div class="form-group">
                <label for="first_name">Name:</label>
                <input type="text" class="form-control" name="Name" id="Name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="Email" id="Email"  placeholder="Enter your emai">
            </div>
            <div class="form-group">
                <label for="last_name">Password:</label>
                <input type="password" class="form-control" name="Password" id="Password"  placeholder="Enter your password">
            </div>
            
            <button type="submit" class="btn btn-success mb-2 " name="save">Save</button>
        </form>
        </div>
    </body>
 </html>