<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Application</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    

        <div class="container mt-5 bg-lite">

        <h2>Records</h2>
        <table class="table table-bordered text-lite">
            <thead>
            <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($records as $record): ?>
                    <tr>
                        <td><?= $record['Id'] ?></td>
                        <td><?= $record['Username'] ?></td>
                        <td><?= $record['Email'] ?></td>
                        <td><?= $record['Password'] ?></td>
                        <td><?= $record['role'] ?></td>
                        <td>
                            <a href="<?= base_url('Admin_dashboard/edit/'.$record['Id']) ?>" class="btn btn-success">Edit</a>
                            <a href="<?= base_url('Admin_dashboard/delete/'.$record['Id']) ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                            
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>