<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .welcome-message {
            margin-top: 50px;
            text-align: center;
        }
        .logout-btn {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- <h2 class="welcome-message">Welcome, <?php echo $username; ?>!</h2> -->
        <div class="card mt-4">
            <div class="card-body">
                <h5 class="card-title">Dashboard Content</h5>
                <p class="card-text">This is your dashboard content. You can add more sections, buttons, or links here.</p>
            </div>
        </div>
        <div class="logout-btn">
            <a href="<?php echo base_url('Login/logout'); ?>" class="btn btn-primary">Logout</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
