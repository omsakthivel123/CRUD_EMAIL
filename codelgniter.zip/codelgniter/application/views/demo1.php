
    <h1>Welcome <?= $this->session->userdata('savename') ?></h1>
    <form action="<?= base_url('demo/save') ?>" method="post">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name">
        
        <!-- You can uncomment and add more fields if needed -->
        <!-- <label for="age">Age:</label> -->
        <!-- <input type="text" name="age" id="age"> -->
       
        <input type="submit" value="Save">
    </form>
    <?php
    
if ($this->session->has_userdata('savename') ){ ?>
    <a href="<?= base_url('demo/save') ?>">clear</a>



 <?php } ?>
