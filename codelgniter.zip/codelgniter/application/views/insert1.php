
<!-- Insert Data Form and Records Table -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Application</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5 bg-danger text-white ">
        <h2 class="text-warning text-info">Insert Data</h2>
        <form action="<?= base_url('Crud1/savedata') ?>" method="post">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" name="first_name" id="first_name">
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" name="last_name" id="last_name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email" id="email">
            </div>
            <button type="submit" class="btn btn-primary mb-2" name="save">Save</button>
        </form>
        </div>
        <hr>

        <div class="container mt-5 bg-lite">

        <h2>Records</h2>
        <table class="table table-bordered text-lite">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($records as $record): ?>
                    <tr>
                        <td><?= $record['id'] ?></td>
                        <td><?= $record['first_name'] ?></td>
                        <td><?= $record['last_name'] ?></td>
                        <td><?= $record['email'] ?></td>
                        <td>
                            <a href="<?= base_url('Crud1/edit/'.$record['id']) ?>" class="btn btn-success">Edit</a>
                            <a href="<?= base_url('Crud1/delete/'.$record['id']) ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>