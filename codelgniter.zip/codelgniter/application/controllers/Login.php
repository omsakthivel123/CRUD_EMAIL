<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Login_model'); // Load the Login_model
    }

    public function index() {
        $this->load->view('login_view');
    }

    public function authenticate() {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login_view');
        } else {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $user = $this->Login_model->authenticate_user($username);
        
    
            if($user==1) {
                // $this->session->set_userdata('user_id', $user['id']);
                $this->load->view('dashboard');
            } else {
                $data['error'] = 'Invalid username or password';
                $this->load->view('login_view', $data);
            }
        }
    }
}
