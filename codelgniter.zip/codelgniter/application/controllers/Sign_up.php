<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sign_up extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        // Load the Sign_model model
        $this->load->model('Sign_model');
    }

public function index(){
        $this->load->view('sign');
    }

    public function savedata(){
        if($this->input->post()) {
            $data['Name'] = $this->input->post('Name');
            $data['Email'] = $this->input->post('Email');
            $data['Password'] = $this->input->post('Password');

            $response = $this->Sign_model->saverecords($data);
            if($response) { 
                echo '<script>alert("Inserted!"); window.location.href="'.base_url('Sign_up').'";</script>';
            } else {
                echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Sign_up').'";</script>'; // Corrected the redirection URL
            }
        }
    }    
   
                                  //    this is only store the datas in uniquly for data base
                                  

    // public function savedata(){
    //     if($this->input->post()) {
    //         $data['Name'] = $this->input->post('Name');
    //         $data['Email'] = $this->input->post('Email');
    //         $data['Password'] = $this->input->post('Password');
    
    //         // Check if the email already exists
    //         $existing_user = $this->Sign_model->get_user_by_email($data['Email']);
    
    //         if($existing_user) {
    //             echo '<script>alert("Email already exists!"); window.location.href="'.base_url('Sign_up').'";</script>';
    //         } else {
    //             $response = $this->Sign_model->saverecords($data);
    //             if($response) { 
    //                 echo '<script>alert("Inserted!"); window.location.href="'.base_url('Sign_up').'";</script>';
    //             } else {
    //                 echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Sign_up').'";</script>'; // Corrected the redirection URL
    //             }
    //         }
    //     }
    // }



                                  //  this is fetch tha data in database for find last ID
                                  

    // public function savedata(){
    //     if($this->input->post()) {
    //         $data['Name'] = $this->input->post('Name');
    //         $data['Email'] = $this->input->post('Email');
    //         $data['Password'] = $this->input->post('Password');
    
    //         $response = $this->Sign_model->saverecords($data);
    
    //         if($response) { 
    //             $last_id = $this->Sign_model->getLastID(); // Call the method to get the last ID
    //             echo 'Your last ID: '.$last_id;
    //         } else {
    //             echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Sign_up').'";</script>';
    //         }
    //     }
    // }
    
}
?>
