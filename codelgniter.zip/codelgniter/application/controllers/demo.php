<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Demo extends CI_Controller {

	
	public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');

	}

    public function index()
    {
        // $this->load->helper('url');
        // $this->load->library('session');
        $this->load->view('demo1');
    }

    public function save()
    {
        // $this->load->helper('url');
        // $this->load->library('session');
        $name = $this->input->post('name');
        $this->session->set_userdata('savename', $name);
        redirect('demo');
    }

	public function clear(){

		// $this->load->helper('url');
		// $this->load->library('session');
		$this->session->unset_userdata('name');
	}
}
