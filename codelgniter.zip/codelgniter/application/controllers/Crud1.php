<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud1 extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Crud_model1');
    }

    public function index() {
        $data['records'] = $this->Crud_model1->get_records();
        $this->load->view('insert1', $data);
    }
    
    public function savedata() {
        if($this->input->post()) {
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['email'] = $this->input->post('email');

            $response = $this->Crud_model1->saverecords($data);

            if($response) { 
                echo '<script>alert("Inserted!"); window.location.href="'.base_url('Crud1').'";</script>';
            } else {
                echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Crud1').'";</script>';
            }
        }
    }

    public function edit($id) {
        $data['record'] = $this->Crud_model1->get_record($id);
        $this->load->view('edit', $data);
    }

    public function update() {
        if($this->input->post()) {
            $id = $this->input->post('id');
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['email'] = $this->input->post('email');
            $response = $this->Crud_model1->update_record($id, $data);

            if($response) { 
                echo '<script>alert("Updated!"); window.location.href="'.base_url('Crud1').'";</script>';
            } else {
                echo '<script>alert("Not Updated!"); window.location.href="'.base_url('Crud1').'";</script>';
            }
        }
    }

    public function delete($id) {
        $response = $this->Crud_model1->delete_record($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Crud1').'";</script>';
        } else {
            echo '<script>alert("Not Deleted!"); window.location.href="'.base_url('Crud1').'";</script>';
        }
    }
}
?>
