<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url'); 
        $this->load->model('User_model');
    }

    
    public function index() {
        $data['records'] = $this->User_model->get_records();
        
        $this->load->view('user_dashboard', $data);
    }
}
