<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Crud_model'); 
    }

    public function index() {
        $this->load->view('insert');
    }

    public function savedata() {
        if($this->input->post()){
            
            $data['first_name'] = $this->input->post('first_name');
            $data['last_name'] = $this->input->post('last_name');
            $data['email'] = $this->input->post('email');

            $response = $this->Crud_model->saverecords($data);

            if($response == true){ 
                echo '<script>alert("innserted!"); window.location.href="index"</script>;';
            } else {
                echo alert(" not innserted!");
            }
            // redirect('Crud');    
        }
    }
}
?>
