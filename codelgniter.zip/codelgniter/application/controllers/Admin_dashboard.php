<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('User_model');
    }

    public function index() {
        $data['records'] = $this->User_model->get_records();
        
        $this->load->view('admin_dashboard', $data);
    }
    
    public function savedata() {
        if($this->input->post()) {
            $data['username'] = $this->input->post('Username');
            $data['email'] = $this->input->post('Email');
            $data['password'] = $this->input->post('Password');
            $data['role'] = $this->input->post('role');

            $response = $this->User_model->saverecords($data);

            if($response) { 
                echo '<script>alert("Inserted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
            } else {
                echo '<script>alert("Not Inserted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
            }
        }
    }

    public function edit($id) {
        $data['record'] = $this->User_model->get_record($id);
        $this->load->view('edit1', $data);
    }

    public function update() {
        if($this->input->post()) {
            $id = $this->input->post('id'); 
            $data['username'] = $this->input->post('username'); 
            $data['email'] = $this->input->post('email'); 
            $data['password'] = $this->input->post('password'); 
            $data['role'] = $this->input->post('role');
    
            $response = $this->User_model->update_record($id, $data);
    
            if($response) { 
                echo '<script>alert("Updated!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
            } else {
                echo '<script>alert("Not Updated!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
            }
        }
    }
    

    public function delete($id) {
        $response = $this->User_model->delete_record($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
        } else {
            echo '<script>alert("Not Deleted!"); window.location.href="'.base_url('Admin_dashboard').'";</script>';
        }
    }
}
?>
