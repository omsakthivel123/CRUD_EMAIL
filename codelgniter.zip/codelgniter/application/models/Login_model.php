 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

  
        public function __construct() {
            parent::__construct();
            $this->load->database(); // Load database library
        }
    
        public function authenticate_user($username, $password) {
            $query = "SELECT * FROM login where username='$username'";
            $b=$this->db->query($query);
            $a=$b->row();
            // print_r($a->Password);
            // print_r($password);
            
        
            
               
                if ($a->Password == $password ) {
                    return 1 ;
                }else{
                    return 0;
                }
           
        }
    }
    
    
    



