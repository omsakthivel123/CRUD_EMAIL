<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function register_user() {
        $data = array(
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password'),
            'role' => $this->input->post('role') 
        );
        return $this->db->insert('users1', $data);
    }
  
    
    public function get($username, $password) {
        $query = $this->db->get_where('users1', array('Username' => $username), 1);
        $user = $query->row();
    
        if ($user && $user->Password == $password) {
            return $user; 
        } else {
            return false; 
        }
    }
    
    
            //   ------------------------ admin-------------

        public function get_records() {
            return $this->db->get('users1')->result_array();
        }
    
        public function get_record($id) {
            return $this->db->get_where('users1', array('Id' => $id))->row_array();
        }
    
        public function saverecords($data) {
            $this->db->insert('users1', $data);
            return $this->db->affected_rows() > 0;
        }
    
        public function update_record($id, $data) {
            $this->db->where('Id', $id);
            $this->db->update('users1', $data);
            // print_r($data);
            // exit;
            return $this->db->affected_rows() > 0;
        }
    
        public function delete_record($id) {
            $this->db->where('Id',$id);
            $this->db->delete('users1');
            return $this->db->affected_rows() > 0;
        }




        // --------------------user------------

        public function get_users() {
            $query = $this->db->get('users1'); 
            return $query->result(); 
        }
    }
    ?>
    


    

