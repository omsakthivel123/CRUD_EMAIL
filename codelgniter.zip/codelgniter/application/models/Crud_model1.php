<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model1 extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_records() {
        return $this->db->get('crud_1')->result_array();
    }

    public function get_record($id) {
        return $this->db->get_where('crud_1', array('id' => $id))->row_array();
    }

    public function saverecords($data) {
        $this->db->insert('crud_1', $data);
        return $this->db->affected_rows() > 0;
    }

    public function update_record($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('crud_1', $data);
        return $this->db->affected_rows() > 0;
    }

    public function delete_record($id) {
        $this->db->where('id',$id);
        $this->db->delete('crud_1');
        return $this->db->affected_rows() > 0;
    }
}
?>
