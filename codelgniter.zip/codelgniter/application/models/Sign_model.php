<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sign_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function saverecords($data) {
        $this->db->insert('signup', $data);
        return ($this->db->affected_rows() > 0) ? true : false;
    }


                //    this is only store the datas in uniquly for data base

    // public function get_user_by_email($email) {
    //     $this->db->where('Email', $email);
    //     $query = $this->db->get('signup'); 
    //     return $query->row_array(); 
    // }




                //  this is fetch tha data in database for find last ID
                 
    // public function getLastID() {
    //     return $this->db->insert_id(); // Retrieve the last inserted ID
    // }
}
?>
