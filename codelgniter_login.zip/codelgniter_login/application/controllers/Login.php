<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session'); 
        $this->load->model('Login_model');
    }
    
    public function index() {
        $this->load->view('login'); 
    }

    public function regist() { 
        $this->load->view('register'); 
    }
    public function login() {
        $name = $this->input->post('name');
        $password = $this->input->post('password');
    
        $user = $this->Login_model->get($name, $password);
     
        if ($user==1) {
            //  print_r('hii');
            //  exit;
            $this->session->set_userdata('id', $user->id);
            redirect('Dashboard/dashboard');
        } else {
            // log_message('error', 'Invalid login attempt. Name: ' . $name . ', Password: ' . $password);
            
            $this->session->set_flashdata('error', 'Invalid username or password');
            redirect('login');
        }
    } 
    

    
}
?>
