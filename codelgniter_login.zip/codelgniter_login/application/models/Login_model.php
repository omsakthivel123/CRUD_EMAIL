<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    
    
    public function get($name, $password) {
        $query = "SELECT * FROM login3 where name='$name'";
        $b=$this->db->query($query);
        $a=$b->row();
      
        // print_r($a);
        // exit;
        if ($a->password == $password ) {

            return 1; 
        } else {
            return false; 
        }
    }


    // public function get_records() {
    //     return $this->db->get('login3')->result_array();
    // }
    
    // public function get_users() {
    //     $query = $this->db->get('login3'); 
    //     return $query->result(); 
    // }
}
?>
